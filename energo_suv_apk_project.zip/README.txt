Energo-Suv Nazorat APK loyihasi
Ushbu loyiha yuklangan index.html asosida Android WebView APK yaratadi.
Android Studio orqali papkani oching va Build > Generate App Bundles or APKs > Generate APKs ni tanlang.
